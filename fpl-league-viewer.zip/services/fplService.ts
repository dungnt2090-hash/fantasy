import { ClassicLeagueResponse, BootstrapStaticResponse, ManagerPicksResponse, LiveEventResponse, ManagerHistoryResponse } from '../types';
import { MOCK_LEAGUE_DATA, MOCK_BOOTSTRAP_DATA, MOCK_PICKS_DATA, MOCK_LIVE_DATA, MOCK_HISTORY_DATA } from '../constants';
import { getCachedData, setCachedData } from './db';

const LEAGUE_ID = 590736;
const FPL_API_BASE = 'https://fantasy.premierleague.com/api';

// Cache Durations (in milliseconds)
const CACHE_TTL = {
  BOOTSTRAP: 1000 * 60 * 60, // 1 hour
  LEAGUE: 1000 * 60 * 5,     // 5 minutes
  PICKS: 1000 * 60 * 60 * 24, // 24 hours (Historical picks don't change often, live points update via LiveData)
  HISTORY: 1000 * 60 * 60,   // 1 hour
  LIVE: 1000 * 60 * 2        // 2 minutes
};

// Helper to race promises and return the first success (like Promise.any)
const raceSuccess = <T>(promises: Promise<T>[]): Promise<T> => {
  return new Promise((resolve, reject) => {
    let rejectionCount = 0;
    if (promises.length === 0) {
        reject(new Error("No promises to execute"));
        return;
    }
    promises.forEach(p => {
      p.then(resolve).catch(() => {
        rejectionCount++;
        if (rejectionCount === promises.length) {
          reject(new Error("All proxy attempts failed"));
        }
      });
    });
  });
};

const fetchWithRetries = async (url: string) => {
  const proxyFactories = [
    (target: string) => `https://corsproxy.io/?${encodeURIComponent(target)}`,
    (target: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(target)}`,
    (target: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(target)}`
  ];

  const requests = proxyFactories.map(async (createUrl) => {
    const proxyUrl = createUrl(url);
    try {
      const res = await fetch(proxyUrl);
      if (!res.ok) throw new Error(`Status ${res.status}`);
      return await res.json();
    } catch (e) {
      throw e;
    }
  });

  return await raceSuccess(requests);
};

// Generic Caching Fetcher
const fetchWithCache = async <T>(key: string, url: string, ttl: number, mockFallback: T): Promise<T> => {
  // 1. Check Cache
  try {
    const cached = await getCachedData<{data: T, timestamp: number}>(key);
    if (cached) {
      const age = Date.now() - cached.timestamp;
      if (age < ttl) {
        // Cache hit and fresh
        return cached.data;
      }
    }
  } catch (e) {
    console.warn("Cache read failed", e);
  }

  // 2. Fetch Network
  try {
    const data = await fetchWithRetries(url);
    // 3. Update Cache
    await setCachedData(key, { data, timestamp: Date.now() });
    return data;
  } catch (error) {
    // 4. Fallback to stale cache if network fails
    const cached = await getCachedData<{data: T, timestamp: number}>(key);
    if (cached) {
      console.warn(`Network failed for ${url}, using stale cache.`);
      return cached.data;
    }
    
    // 5. Fallback to Mock
    console.warn(`Network failed for ${url} and no cache. Using mock.`);
    return mockFallback; 
  }
};

export const fetchLeagueData = async (): Promise<ClassicLeagueResponse> => {
  const targetUrl = `${FPL_API_BASE}/leagues-classic/${LEAGUE_ID}/standings/`;
  return fetchWithCache(
    `league_${LEAGUE_ID}`, 
    targetUrl, 
    CACHE_TTL.LEAGUE, 
    MOCK_LEAGUE_DATA
  );
};

export const fetchBootstrapStatic = async (): Promise<BootstrapStaticResponse> => {
  const targetUrl = `${FPL_API_BASE}/bootstrap-static/`;
  return fetchWithCache(
    `bootstrap_static`, 
    targetUrl, 
    CACHE_TTL.BOOTSTRAP, 
    MOCK_BOOTSTRAP_DATA
  );
};

export const fetchManagerPicks = async (managerId: number, eventId: number): Promise<ManagerPicksResponse> => {
  const targetUrl = `${FPL_API_BASE}/entry/${managerId}/event/${eventId}/picks/`;
  return fetchWithCache(
    `picks_${managerId}_${eventId}`, 
    targetUrl, 
    CACHE_TTL.PICKS, 
    MOCK_PICKS_DATA
  );
};

export const fetchManagerHistory = async (managerId: number): Promise<ManagerHistoryResponse> => {
  const targetUrl = `${FPL_API_BASE}/entry/${managerId}/history/`;
  return fetchWithCache(
    `history_${managerId}`, 
    targetUrl, 
    CACHE_TTL.HISTORY, 
    MOCK_HISTORY_DATA
  );
};

export const fetchLiveEventData = async (eventId: number): Promise<LiveEventResponse> => {
  const targetUrl = `${FPL_API_BASE}/event/${eventId}/live/`;
  return fetchWithCache(
    `live_${eventId}`, 
    targetUrl, 
    CACHE_TTL.LIVE, 
    MOCK_LIVE_DATA
  );
};

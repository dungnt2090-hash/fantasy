import React, { useMemo, useEffect, useState, useRef } from 'react';
import { Standings, BootstrapStaticResponse, LiveEventResponse, ManagerPicksResponse, SortConfig, ManagerHistoryResponse } from '../types';
import { fetchManagerPicks, fetchManagerHistory } from '../services/fplService';
import { ManagerTeamView } from './ManagerTeamView';

interface LeagueTableProps {
  standings: Standings;
  sortConfig: SortConfig;
  onSortChange: (config: SortConfig) => void;
  highlightEntryId?: number | null;
  bootstrapData: BootstrapStaticResponse | null;
  liveData: LiveEventResponse | null;
  currentEventId: number | null;
}

// Helper to determine row styling based on rank
const getRankStyles = (rank: number) => {
  if (rank === 1) return "bg-yellow-50 border-l-4 border-yellow-400"; // Gold
  if (rank === 2) return "bg-gray-50 border-l-4 border-gray-400"; // Silver
  if (rank === 3) return "bg-orange-50 border-l-4 border-orange-400"; // Bronze
  return "hover:bg-gray-50 border-l-4 border-transparent";
};

const RankBadge = ({ rank }: { rank: number }) => {
  if (rank === 1) return <span className="text-xl">🏆</span>;
  if (rank === 2) return <span className="text-xl">🥈</span>;
  if (rank === 3) return <span className="text-xl">🥉</span>;
  return <span className="font-bold text-gray-700">{rank}</span>;
};

// Sortable Header Component
const SortableHeader = ({ 
  label, 
  sortKey, 
  currentConfig, 
  onSort, 
  className = "",
  center = true
}: { 
  label: string, 
  sortKey: string, 
  currentConfig: SortConfig, 
  onSort: (c: SortConfig) => void,
  className?: string,
  center?: boolean
}) => {
    const isActive = currentConfig.key === sortKey;
    return (
        <th 
            className={`py-4 px-4 text-center cursor-pointer select-none hover:bg-white/10 transition-colors ${className} ${isActive ? 'bg-white/10 text-white' : 'text-gray-300'} ${!center ? 'text-left' : ''}`}
            onClick={() => {
                let direction: 'asc' | 'desc' = 'desc';
                if (isActive) {
                    direction = currentConfig.direction === 'desc' ? 'asc' : 'desc';
                } else {
                    // Default sort directions based on column type
                    if (['team', 'captain', 'vice', 'chip', 'fees'].includes(sortKey)) direction = 'asc';
                }
                onSort({ key: sortKey, direction });
            }}
        >
            <div className={`flex items-center space-x-1 ${center ? 'justify-center' : 'justify-start'}`}>
                <span>{label}</span>
                {isActive && (
                    <span className="text-xs">{currentConfig.direction === 'desc' ? '▼' : '▲'}</span>
                )}
            </div>
        </th>
    );
};

export const LeagueTable: React.FC<LeagueTableProps> = ({ 
  standings, 
  sortConfig, 
  onSortChange,
  highlightEntryId,
  bootstrapData,
  liveData,
  currentEventId
}) => {
  
  const [enrichedData, setEnrichedData] = useState<Record<number, ManagerPicksResponse>>({});
  const [historyData, setHistoryData] = useState<Record<number, ManagerHistoryResponse>>({});
  const [loadingDetails, setLoadingDetails] = useState<boolean>(false);
  
  // Hover State
  const [hoveredEntry, setHoveredEntry] = useState<number | null>(null);
  const [popupPosition, setPopupPosition] = useState<{top: number, left: number} | null>(null);
  const tableRef = useRef<HTMLDivElement>(null);

  // Optimization: Map player ID to Name for fast lookup during sort
  const playerMap = useMemo(() => {
    const map = new Map<number, string>();
    if (bootstrapData) {
        bootstrapData.elements.forEach(e => map.set(e.id, e.web_name));
    }
    return map;
  }, [bootstrapData]);

  // Calculate GW Wins and Fees
  const { gwWins, totalFees } = useMemo(() => {
    const wins: Record<number, number> = {};
    const fees: Record<number, number> = {};
    const entries = standings.results.map(r => r.entry);
    
    const availableHistories = entries.filter(id => historyData[id]);
    
    if (availableHistories.length === 0) return { gwWins: wins, totalFees: fees };
    
    // Initialize
    availableHistories.forEach(id => {
        wins[id] = 0;
        fees[id] = 0;
    });

    // Find max event ID from available data
    let maxEvent = 0;
    availableHistories.forEach(id => {
        const hist = historyData[id];
        if (hist.current.length > 0) {
            const last = hist.current[hist.current.length - 1].event;
            if (last > maxEvent) maxEvent = last;
        }
    });

    // Iterate through all GWs to calculate Wins and Fees
    for (let gw = 1; gw <= maxEvent; gw++) {
        // Collect scores for this GW
        const gwScores: {id: number, score: number}[] = [];
        
        availableHistories.forEach(id => {
            const hist = historyData[id];
            const gwData = hist.current.find(e => e.event === gw);
            if (gwData) {
                gwScores.push({ id, score: gwData.points });
            }
        });

        // Skip if no data for this GW
        if (gwScores.length === 0) continue;

        // Sort descending to determine rank
        gwScores.sort((a, b) => b.score - a.score);

        // --- Calculate Wins (Top 1) ---
        const maxScore = gwScores[0].score;
        gwScores.forEach(entry => {
            if (entry.score === maxScore) {
                wins[entry.id] = (wins[entry.id] || 0) + 1;
            }
        });

        // --- Calculate Fees ---
        // Rule: (Rank - 1) * 5000 VND
        // Standard competition ranking (1224)
        for (let i = 0; i < gwScores.length; i++) {
            const currentEntry = gwScores[i];
            let rank = i + 1;

            // Handle Ties: Check if score matches previous
            if (i > 0 && currentEntry.score === gwScores[i-1].score) {
                // Find the first index that had this score
                let firstIndex = i;
                while(firstIndex > 0 && gwScores[firstIndex-1].score === currentEntry.score) {
                    firstIndex--;
                }
                rank = firstIndex + 1;
            }

            const cost = (rank - 1) * 5000;
            fees[currentEntry.id] = (fees[currentEntry.id] || 0) + cost;
        }
    }
    return { gwWins: wins, totalFees: fees };
  }, [historyData, standings.results]);

  // 1. Calculate GW Ranks for everyone first (Static, based on raw scores)
  const dataWithGWRank = useMemo(() => {
    // Sort all results by GW points descending for ranking
    const byGW = [...standings.results].sort((a, b) => b.event_total - a.event_total);
    
    const rankMap = new Map<number, number>();
    byGW.forEach((item, index) => {
      const prevItem = index > 0 ? byGW[index - 1] : null;
      let rank = index + 1;
      if (prevItem && prevItem.event_total === item.event_total) {
        rank = rankMap.get(prevItem.entry) || rank;
      }
      rankMap.set(item.entry, rank);
    });

    return standings.results.map(item => ({
      ...item,
      calculated_gw_rank: rankMap.get(item.entry) || 0
    }));

  }, [standings.results]);

  // 2. Sort the final list for display based on user preference
  const sortedResults = useMemo(() => {
    return [...dataWithGWRank].sort((a, b) => {
      const detailsA = enrichedData[a.entry];
      const detailsB = enrichedData[b.entry];
      const winsA = gwWins[a.entry] || 0;
      const winsB = gwWins[b.entry] || 0;
      const feesA = totalFees[a.entry] || 0;
      const feesB = totalFees[b.entry] || 0;

      let valA: any = '';
      let valB: any = '';

      switch (sortConfig.key) {
        case 'gw':
          valA = a.event_total;
          valB = b.event_total;
          break;
        case 'total':
          valA = a.total;
          valB = b.total;
          break;
        case 'team':
          valA = a.entry_name.toLowerCase();
          valB = b.entry_name.toLowerCase();
          break;
        case 'hits':
           valA = detailsA ? detailsA.entry_history.event_transfers_cost : 0;
           valB = detailsB ? detailsB.entry_history.event_transfers_cost : 0;
           break;
        case 'chip':
            valA = detailsA?.active_chip || '';
            valB = detailsB?.active_chip || '';
            break;
        case 'transfers':
            valA = detailsA ? detailsA.entry_history.event_transfers : 0;
            valB = detailsB ? detailsB.entry_history.event_transfers : 0;
            break;
        case 'captain': {
            const capIdA = detailsA?.picks.find(p => p.is_captain)?.element;
            const capIdB = detailsB?.picks.find(p => p.is_captain)?.element;
            valA = capIdA ? (playerMap.get(capIdA) || '') : '';
            valB = capIdB ? (playerMap.get(capIdB) || '') : '';
            break;
        }
        case 'vice': {
            const viceIdA = detailsA?.picks.find(p => p.is_vice_captain)?.element;
            const viceIdB = detailsB?.picks.find(p => p.is_vice_captain)?.element;
            valA = viceIdA ? (playerMap.get(viceIdA) || '') : '';
            valB = viceIdB ? (playerMap.get(viceIdB) || '') : '';
            break;
        }
        case 'top1':
            valA = winsA;
            valB = winsB;
            break;
        case 'fees':
            valA = feesA;
            valB = feesB;
            break;
        default:
          valA = a.total;
          valB = b.total;
      }

      // Handle sort direction
      if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
      if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [dataWithGWRank, sortConfig, enrichedData, playerMap, gwWins, totalFees]);

  // 3. Fetch details AND history for all entries (batched)
  useEffect(() => {
    const fetchDetails = async () => {
        if (!currentEventId) return;
        
        // Identify entries that are not yet enriched or missing history
        const missingEntries = standings.results
            .map(r => r.entry)
            .filter(id => !enrichedData[id] || !historyData[id]);
        
        if (missingEntries.length === 0) return;
        
        setLoadingDetails(true);
        try {
            const chunkSize = 10;
            for (let i = 0; i < missingEntries.length; i += chunkSize) {
                const chunk = missingEntries.slice(i, i + chunkSize);
                
                // Fetch Picks
                const pickPromises = chunk.map(id => 
                    fetchManagerPicks(id, currentEventId).then(data => ({ id, data, type: 'picks' as const }))
                );
                // Fetch History
                const histPromises = chunk.map(id =>
                    fetchManagerHistory(id).then(data => ({ id, data, type: 'history' as const }))
                );

                const results = await Promise.all([...pickPromises, ...histPromises]);
                
                // Update state in one go per chunk to avoid thrashing
                setEnrichedData(prev => {
                    const next = { ...prev };
                    results.filter(r => r.type === 'picks').forEach(r => next[r.id] = r.data as ManagerPicksResponse);
                    return next;
                });

                setHistoryData(prev => {
                    const next = { ...prev };
                    results.filter(r => r.type === 'history').forEach(r => next[r.id] = r.data as ManagerHistoryResponse);
                    return next;
                });
            }
        } catch (e) {
            console.error("Failed to fetch details/history", e);
        } finally {
            setLoadingDetails(false);
        }
    };

    fetchDetails();
  }, [standings.results, currentEventId]); // Only run when results change

  // Helper to calculate played
  const getPlayed = (picks: ManagerPicksResponse['picks'], activeChip: string | null) => {
      if (!liveData) return "0/0";
      const isBB = activeChip === 'bboost';
      const countTotal = isBB ? 15 : 11;
      const relevantPicks = isBB ? picks : picks.filter(p => p.position <= 11);
      
      const playedCount = relevantPicks.reduce((acc, pick) => {
          const stats = liveData.elements.find(e => e.id === pick.element)?.stats;
          if (stats && stats.minutes > 0) return acc + 1;
          return acc;
      }, 0);

      return `${playedCount}/${countTotal}`;
  };

  const handleMouseEnter = (event: React.MouseEvent<HTMLTableRowElement>, entryId: number) => {
      const rect = event.currentTarget.getBoundingClientRect();
      // Position popup below the row, centered horizontally or aligned to a sensible column
      // We'll align it to the right side of the row for visibility
      const tableRect = tableRef.current?.getBoundingClientRect();
      if (!tableRect) return;

      const top = rect.top + window.scrollY + 10;
      // Position logic: prefer right side, flip if close to edge
      const left = Math.min(rect.right + 20, window.innerWidth - 420); 
      
      setPopupPosition({ top, left });
      setHoveredEntry(entryId);
  };

  const handleMouseLeave = () => {
      setHoveredEntry(null);
      setPopupPosition(null);
  };

  return (
    <div className="relative" ref={tableRef}>
      <div className="overflow-hidden rounded-lg shadow-lg bg-white border border-gray-200">
        <div className="overflow-x-auto">
          <table className="min-w-full w-full text-sm text-left whitespace-nowrap">
            <thead className="bg-gray-900 text-white font-bold border-b border-gray-200">
              <tr>
                <th className="py-4 px-4 w-16 text-center">Rank</th>
                
                <SortableHeader 
                    label="Team & Manager" 
                    sortKey="team" 
                    currentConfig={sortConfig} 
                    onSort={onSortChange} 
                    className="min-w-[200px]"
                    center={false}
                />
                <SortableHeader 
                    label="GW" 
                    sortKey="gw" 
                    currentConfig={sortConfig} 
                    onSort={onSortChange} 
                />
                
                <SortableHeader label="Top 1s" sortKey="top1" currentConfig={sortConfig} onSort={onSortChange} />
                
                <SortableHeader label="Chip" sortKey="chip" currentConfig={sortConfig} onSort={onSortChange} />
                <SortableHeader label="Captain" sortKey="captain" currentConfig={sortConfig} onSort={onSortChange} />
                <SortableHeader label="Vice" sortKey="vice" currentConfig={sortConfig} onSort={onSortChange} />
                
                <th className="py-4 px-4 text-center">Played</th>
                <SortableHeader label="Fees (VNĐ)" sortKey="fees" currentConfig={sortConfig} onSort={onSortChange} />
                <th className="py-4 px-4 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {sortedResults.map((player) => {
                const gwRank = player.calculated_gw_rank;
                const rowStyle = getRankStyles(gwRank);
                const details = enrichedData[player.entry];
                const wins = gwWins[player.entry] || 0;
                const fees = totalFees[player.entry] || 0;

                // Derived Data
                
                const activeChipMap: Record<string, string> = {
                    'bboost': 'BB',
                    '3xc': 'TC',
                    'freehit': 'FH',
                    'wildcard': 'WC'
                };
                const chip = details?.active_chip ? (activeChipMap[details.active_chip] || details.active_chip) : '';
                
                const captainId = details?.picks.find(p => p.is_captain)?.element;
                const captainName = captainId ? (playerMap.get(captainId) || 'Unknown') : '-';
                
                const viceId = details?.picks.find(p => p.is_vice_captain)?.element;
                const viceName = viceId ? (playerMap.get(viceId) || 'Unknown') : '-';
                
                const played = details ? getPlayed(details.picks, details.active_chip) : '-';

                return (
                <tr 
                  key={player.id} 
                  className={`transition-colors duration-150 group cursor-help relative ${rowStyle}`}
                  onMouseEnter={(e) => handleMouseEnter(e, player.entry)}
                  onMouseLeave={handleMouseLeave}
                >
                  <td className="py-3 px-4 text-center">
                    <div className="flex flex-col items-center justify-center">
                      <RankBadge rank={gwRank} />
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-fpl-purple text-base leading-tight decoration-fpl-green underline-offset-2">
                          {player.entry_name}
                      </span>
                      <span className="text-gray-500 text-xs mt-1">{player.player_name}</span>
                    </div>
                  </td>
                  <td className={`py-3 px-4 text-center ${sortConfig.key === 'gw' ? 'bg-purple-50 font-bold text-fpl-purple text-lg' : 'text-gray-700 font-semibold'}`}>
                    {player.event_total}
                  </td>
                  
                  {/* GW Wins Column */}
                  <td className="py-3 px-4 text-center">
                     {wins > 0 && (
                         <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-yellow-100 text-yellow-800 border border-yellow-200">
                             🏆 {wins}
                         </span>
                     )}
                     {wins === 0 && <span className="text-gray-400">-</span>}
                  </td>

                  <td className="py-3 px-4 text-center">
                      {chip ? <span className="bg-fpl-purple text-white px-2 py-1 rounded text-xs font-bold">{chip}</span> : '-'}
                  </td>
                  <td className="py-3 px-4 text-center font-medium text-gray-800">
                      {captainName}
                  </td>
                  <td className="py-3 px-4 text-center text-gray-500">
                      {viceName}
                  </td>
                  <td className="py-3 px-4 text-center font-semibold text-gray-800">
                      {played}
                  </td>

                  {/* Fees Column */}
                  <td className="py-3 px-4 text-center font-semibold text-gray-800">
                      {fees > 0 ? (
                          <span className="text-red-600">
                              {fees.toLocaleString('vi-VN')} đ
                          </span>
                      ) : (
                          <span className="text-green-600">0 đ</span>
                      )}
                  </td>

                  <td className="py-3 px-4 text-center">
                     <div 
                       className="text-gray-400 group-hover:text-fpl-purple transition-colors"
                     >
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                       </svg>
                     </div>
                  </td>
                </tr>
              )})}
            </tbody>
          </table>
        </div>
        {sortedResults.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            No players found in this league.
          </div>
        )}
      </div>
      
      {/* Popup Manager View */}
      {hoveredEntry && popupPosition && enrichedData[hoveredEntry] && bootstrapData && liveData && (
          <div 
            className="fixed z-[100] pointer-events-none"
            style={{ 
                top: Math.min(popupPosition.top, window.innerHeight - 550), // Prevent going off bottom screen
                left: popupPosition.left,
                transform: 'translateY(-10%)' // Slightly offset up
            }}
          >
             <ManagerTeamView 
                managerName={standings.results.find(r => r.entry === hoveredEntry)?.entry_name || ""}
                picks={enrichedData[hoveredEntry]}
                bootstrap={bootstrapData}
                liveData={liveData}
                isPopup={true}
             />
          </div>
      )}
    </div>
  );
};
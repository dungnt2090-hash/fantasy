import React from 'react';

interface HeaderProps {
    currentGameweek?: string;
}

export const Header: React.FC<HeaderProps> = ({ currentGameweek }) => {
  return (
    <header className="bg-fpl-purple relative overflow-hidden shadow-md">
        {/* Decorative background pattern simulation */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
             <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                 <path d="M0 100 L100 0 L100 100 Z" fill="#00ff85" />
             </svg>
        </div>

        <div className="max-w-4xl mx-auto px-4 py-6 relative z-10 flex items-center justify-between">
            <div className="flex items-center space-x-4">
                <div className="h-12 w-12 bg-fpl-green rounded-lg flex items-center justify-center shadow-lg transform rotate-3">
                    <span className="text-fpl-purple font-bold text-xl">PL</span>
                </div>
                <div>
                    <h1 className="text-white text-2xl font-bold tracking-tight">Fantasy Premier League</h1>
                    <p className="text-fpl-green text-sm font-medium uppercase tracking-wider">Official Data Viewer</p>
                </div>
            </div>
            
            <div className="hidden sm:block">
               <div className="text-right">
                   <p className="text-white text-xs opacity-75">Season 2023/24</p>
                   <p className="text-white font-bold text-xl">{currentGameweek || 'Loading...'}</p>
               </div>
            </div>
        </div>
        
        {/* Navigation Bar simulation */}
        <div className="bg-fpl-dark mt-2">
             <div className="max-w-4xl mx-auto px-4">
                 <nav className="flex space-x-6 text-sm font-medium text-white overflow-x-auto py-3 no-scrollbar">
                     <button className="opacity-70 hover:opacity-100 hover:text-fpl-green transition-colors whitespace-nowrap">Fantasy</button>
                     <button className="opacity-70 hover:opacity-100 hover:text-fpl-green transition-colors whitespace-nowrap">Fantasy Challenge</button>
                     <button className="opacity-70 hover:opacity-100 hover:text-fpl-green transition-colors whitespace-nowrap">Premier League</button>
                     <button className="text-fpl-green border-b-2 border-fpl-green pb-1 whitespace-nowrap">Leagues</button>
                 </nav>
             </div>
        </div>
    </header>
  );
};

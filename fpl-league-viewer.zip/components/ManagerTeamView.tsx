import React from 'react';
import { ManagerPicksResponse, BootstrapStaticResponse, Pick, LiveEventResponse } from '../types';

interface ManagerTeamViewProps {
  managerName: string;
  picks: ManagerPicksResponse;
  bootstrap: BootstrapStaticResponse;
  liveData: LiveEventResponse;
  onClose?: () => void;
  isPopup?: boolean; // New prop to control display mode
}

export const ManagerTeamView: React.FC<ManagerTeamViewProps> = ({ managerName, picks, bootstrap, liveData, onClose, isPopup = false }) => {
  const getPlayerDetails = (elementId: number) => {
    return bootstrap.elements.find(el => el.id === elementId);
  };

  const getTeamDetails = (teamId: number) => {
    return bootstrap.teams.find(t => t.id === teamId);
  };

  const getLivePoints = (elementId: number) => {
    const liveElement = liveData.elements.find(el => el.id === elementId);
    return liveElement ? liveElement.stats.total_points : 0;
  };

  const getTypeLabel = (typeId: number) => {
    switch(typeId) {
      case 1: return 'GKP';
      case 2: return 'DEF';
      case 3: return 'MID';
      case 4: return 'FWD';
      default: return '';
    }
  };

  // Helper to render a player on the pitch
  const PlayerCard: React.FC<{ pick: Pick, isBench?: boolean }> = ({ pick, isBench = false }) => {
    const player = getPlayerDetails(pick.element);
    if (!player) return null;
    const team = getTeamDetails(player.team);
    
    const gwPoints = getLivePoints(pick.element);
    const finalPoints = gwPoints * pick.multiplier;

    // Use smaller sizes for popup mode
    const widthClass = isPopup ? "w-14" : "w-20 md:w-24";
    const imgSizeClass = isPopup ? "w-8 h-10" : "w-12 h-16 md:w-16 md:h-20";
    const textSizeClass = isPopup ? "text-[8px]" : "text-[10px] md:text-xs";
    const pointsSizeClass = isPopup ? "text-[10px]" : "text-xs md:text-sm";

    const shirtUrl = team 
        ? `https://fantasy.premierleague.com/dist/img/shirts/standard/shirt_${team.code}${player.element_type === 1 ? '_1' : ''}-66.webp`
        : 'https://fantasy.premierleague.com/dist/img/shirts/standard/shirt_0-66.webp'; 

    return (
      <div className={`flex flex-col items-center justify-start ${widthClass} relative group`}>
        
        {/* Shirt Image */}
        <div className="relative mb-0.5 transition-transform transform group-hover:scale-110 duration-200">
           <img 
             src={shirtUrl} 
             alt={team?.short_name} 
             className={`${imgSizeClass} object-contain drop-shadow-md`}
             onError={(e) => {
                 (e.target as HTMLImageElement).src = 'https://fantasy.premierleague.com/dist/img/shirts/standard/shirt_0-66.webp';
             }}
           />
           {pick.is_captain && (
               <div className={`absolute -top-1 -right-1 bg-black text-white ${isPopup ? "text-[8px] w-3 h-3" : "text-[10px] w-5 h-5"} font-bold flex items-center justify-center rounded-full border border-white`}>
                   C
               </div>
           )}
           {pick.is_vice_captain && (
               <div className={`absolute -top-1 -right-1 bg-gray-500 text-white ${isPopup ? "text-[8px] w-3 h-3" : "text-[10px] w-5 h-5"} font-bold flex items-center justify-center rounded-full border border-white`}>
                   V
               </div>
           )}
        </div>

        {/* Player Name Box */}
        <div className="bg-fpl-purple text-white w-full text-center rounded-t-sm overflow-hidden z-10 shadow-sm">
             <div className={`bg-white text-gray-900 ${textSizeClass} font-bold py-px px-1 truncate border-b border-gray-200`}>
                 {player.web_name}
             </div>
        </div>

        {/* Points Box */}
        <div className={`bg-fpl-purple text-white ${pointsSizeClass} font-bold w-full text-center py-px rounded-b-sm border-t border-fpl-purple/50 z-10 shadow-sm`}>
             {finalPoints}
        </div>
        
        {isBench && !isPopup && (
           <div className="mt-1 text-[9px] text-gray-500 uppercase font-bold tracking-wider">
               {getTypeLabel(player.element_type)}
           </div>
        )}
      </div>
    );
  };

  const starters = picks.picks.filter(p => p.position <= 11);
  const bench = picks.picks.filter(p => p.position > 11);

  const gkp = starters.filter(p => getPlayerDetails(p.element)?.element_type === 1);
  const def = starters.filter(p => getPlayerDetails(p.element)?.element_type === 2);
  const mid = starters.filter(p => getPlayerDetails(p.element)?.element_type === 3);
  const fwd = starters.filter(p => getPlayerDetails(p.element)?.element_type === 4);

  // Layout Containers
  const MainWrapper = isPopup 
    ? ({ children }: { children: React.ReactNode }) => (
        <div className="bg-white rounded-lg shadow-2xl overflow-hidden border-2 border-fpl-purple w-[380px]">
            {children}
        </div>
      )
    : ({ children }: { children: React.ReactNode }) => (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-75 flex items-end md:items-center justify-center p-0 md:p-4 backdrop-blur-sm">
           <div className="bg-white md:rounded-xl w-full max-w-2xl flex flex-col shadow-2xl overflow-hidden h-[100dvh] md:h-auto md:max-h-[90vh]">
             {children}
           </div>
        </div>
    );

  const Header = () => (
    <div className={`${isPopup ? 'p-2' : 'p-4'} bg-fpl-purple text-white flex justify-between items-center shrink-0 shadow-md z-10`}>
         <div className="flex-1 min-w-0 mr-2">
            <h3 className={`${isPopup ? 'text-sm' : 'text-lg'} font-bold tracking-tight truncate`}>{managerName}</h3>
            {!isPopup && (
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs md:text-sm text-fpl-green font-medium">
                    <span className="whitespace-nowrap">GW{picks.entry_history.event}</span>
                    <span className="text-white/40">•</span>
                    <span className="whitespace-nowrap">{picks.entry_history.points} Pts</span>
                    <span className="text-white/40">•</span>
                    <span className="whitespace-nowrap">Rank {picks.entry_history.rank.toLocaleString()}</span>
                </div>
            )}
            {isPopup && (
                <div className="text-xs text-fpl-green font-medium">
                    {picks.entry_history.points} Pts
                </div>
            )}
         </div>
         {!isPopup && onClose && (
             <button onClick={onClose} className="bg-white/10 hover:bg-white/20 text-white rounded-full p-2 transition-colors shrink-0">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
               </svg>
             </button>
         )}
    </div>
  );

  return (
    <MainWrapper>
        <Header />
        <div className={`flex-1 ${isPopup ? '' : 'overflow-y-auto relative'} bg-gray-100`}>
             
             {/* Pitch Container */}
             <div className={`relative w-full ${isPopup ? 'h-[400px]' : 'aspect-[3/4] md:aspect-auto md:min-h-[600px]'} bg-gradient-to-b from-[#00ff85] to-[#01c969] shadow-inner overflow-hidden border-b-4 border-fpl-purple`}>
                
                {/* Pitch Markings - Scaled down for popup */}
                <div className="absolute inset-4 border-2 border-white/40 rounded-sm pointer-events-none"></div>
                <div className="absolute top-4 left-1/4 right-1/4 h-16 border-b-2 border-l-2 border-r-2 border-white/40 pointer-events-none"></div>
                <div className="absolute bottom-4 left-1/4 right-1/4 h-16 border-t-2 border-l-2 border-r-2 border-white/40 pointer-events-none"></div>
                <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-white/40 transform -translate-y-1/2 pointer-events-none"></div>
                <div className="absolute top-1/2 left-1/2 w-24 h-24 border-2 border-white/40 rounded-full transform -translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>

                {/* Players Grid */}
                <div className={`absolute inset-0 flex flex-col justify-around ${isPopup ? 'py-2' : 'py-6 md:py-8'}`}>
                    <div className="flex justify-center w-full z-10">{gkp.map(p => <PlayerCard key={p.element} pick={p} />)}</div>
                    <div className="flex justify-center space-x-1 md:space-x-8 w-full px-1 z-10">{def.map(p => <PlayerCard key={p.element} pick={p} />)}</div>
                    <div className="flex justify-center space-x-1 md:space-x-8 w-full px-1 z-10">{mid.map(p => <PlayerCard key={p.element} pick={p} />)}</div>
                    <div className="flex justify-center space-x-1 md:space-x-12 w-full px-1 z-10">{fwd.map(p => <PlayerCard key={p.element} pick={p} />)}</div>
                </div>
             </div>

             {/* Bench Container */}
             <div className={`bg-gray-100 ${isPopup ? 'p-2' : 'p-4 pt-4 pb-8'}`}>
                 <div className={`bg-white rounded-xl ${isPopup ? 'p-2' : 'p-4'} shadow-sm border border-gray-200`}>
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 text-center border-b border-gray-100 pb-1">Bench</h4>
                    <div className="flex justify-center space-x-1 md:space-x-6">
                        {bench.map(p => <PlayerCard key={p.element} pick={p} isBench />)}
                    </div>
                 </div>
             </div>

        </div>
    </MainWrapper>
  );
};